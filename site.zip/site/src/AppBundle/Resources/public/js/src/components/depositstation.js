Vue.component('deposit-station', function (resolve, reject) {
    ajax.get('/data', {}, function (response) {
        let lc = localStorage.getItem('deposit-station'),
            savedState = lc ? JSON.parse(lc) : null,
            object = {
                navAction: savedState ? savedState['navAction'] : {},
                dsData: null,
                showGroup: savedState ? savedState['showGroup'] : null
            };

        try {
            object['dsData'] = JSON.parse(response);
        } catch (e) {

        }

        if (object) {
            resolve({
                template: [
                    '<div class="deposit-station">',
                    '    <ul class="dep-st-list">',
                    '        <label v-if="showGroup" @click="goBack">Back</label>',
                    '        <li class="dep-st-item" v-for="patient in sortOrFilteredList">',
                    '            <div v-if="navAction.group && !showGroup">',
                    '                <label @click="displayGroup(patient)">{{ patient.name }}</label>',
                    '            </div>',
                    '            <div v-else>',
                    '            <div class="v-mask" @click="showDetails(patient, $event)"></div>',
                    '            <label>{{ patient.label }}</label>',
                    '            <label>Tel: {{ patient.details.tel  }} <span v-if="!patient.details.tel">-</span></label>',
                    '            <label v-for="(detail, key) in patient.details" v-if="key !== \'tel\'" class="hidden" v-bind:class="{ show: patient.visible }">',
                    '                {{ key }} - {{ detail }}',
                    '            </label>',
                    '            </div>',
                    '        </li>',
                    '    </ul>',
                    '    <ul class="dep-st-nav">',
                    '        <ul class="dep-st-nav-list">',
                    '            <li class="dep-st-nav-item" v-for="action in dsData.navigation">',
                    '                <label @click="doAction(action)">{{ action.name }}</label>',
                    '            </li>',
                    '        </ul>',
                    '    </ul>',
                    '    <div class="more-btn">More</div>',
                    '</div>',
                ].join(''),

                data: function () {
                    return object;
                },

                methods: {
                    showDetails: function (patient) {
                        Vue.set(patient, 'visible', !patient.visible);
                    },
                    doAction: function (action) {
                        this.showGroup = null;
                        this.navAction = action;
                        localStorage.setItem('deposit-station', JSON.stringify({
                            navAction: this.navAction,
                            showGroup: this.showGroup
                        }));
                    },
                    displayGroup: function (group) {
                        this.showGroup = null;
                        this.showGroup = group.items;
                        localStorage.setItem('deposit-station', JSON.stringify({
                            navAction: this.navAction,
                            showGroup: this.showGroup
                        }));
                    },
                    goBack: function () {
                        this.showGroup = null;
                        localStorage.setItem('deposit-station', JSON.stringify({
                            navAction: this.navAction,
                            showGroup: this.showGroup
                        }));
                    }
                },

                computed: {
                    sortOrFilteredList: function () {
                        let filterType = this.navAction.filter,
                            grouped = this.navAction.group === true,
                            list;

                        if (this.showGroup) {
                            return this.showGroup;
                        } else {
                            if (grouped) {
                                list = this['dsData']['collections']['patient'].reduce(function (groups, item) {
                                    let groupObj = groups[item.group];

                                    if (!groupObj) {
                                        groups[item.group] = {
                                            name: item.group,
                                            active: item.status === 1,
                                            items: []
                                        };
                                    } else {
                                        if (groupObj.active) {
                                            groupObj.active = item.status === 1;
                                            groupObj.items.push(item);
                                        }
                                    }

                                    return groups;
                                }, {});
                            } else {
                                if (filterType) {
                                    list = this['dsData']['collections']['patient'].filter(function (patient) {
                                        let retValue = true;

                                        Object.keys(filterType).forEach(function (key) {
                                            if (patient[key] !== filterType[key]) {
                                                retValue = false;
                                            }
                                        });

                                        return retValue;
                                    });
                                } else {
                                    list = this['dsData']['collections']['patient'];
                                }
                            }
                        }

                        return list;
                    }
                }
            })
        }
    });
})