<?php

// TwigBundle:Exception:exception.txt.twig
return array (
);
