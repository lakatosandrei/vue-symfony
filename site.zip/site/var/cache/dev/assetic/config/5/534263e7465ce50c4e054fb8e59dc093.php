<?php

// DoctrineBundle:Collector:db.html.twig
return array (
);
