<?php

// AppBundle:SP:display.html.twig
return array (
  '8d9955a' => 
  array (
    0 => 
    array (
      0 => 'bundles/app/css/*',
    ),
    1 => 
    array (
    ),
    2 => 
    array (
      'output' => '_controller/css/app.css',
      'name' => '8d9955a',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
  '9c5dbf4' => 
  array (
    0 => 
    array (
      0 => '@AppBundle/Resources/public/js/framework/*',
      1 => '@AppBundle/Resources/public/js/src/components/*',
      2 => '@AppBundle/Resources/public/js/src/main.js',
    ),
    1 => 
    array (
    ),
    2 => 
    array (
      'output' => '_controller/js/app.js',
      'name' => '9c5dbf4',
      'debug' => NULL,
      'combine' => NULL,
      'vars' => 
      array (
      ),
    ),
  ),
);
