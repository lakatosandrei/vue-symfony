<?php

// TwigBundle:Exception:logs.html.twig
return array (
);
