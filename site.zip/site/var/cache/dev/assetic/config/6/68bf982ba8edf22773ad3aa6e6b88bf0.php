<?php

// WebProfilerBundle:Profiler:toolbar_item.html.twig
return array (
);
