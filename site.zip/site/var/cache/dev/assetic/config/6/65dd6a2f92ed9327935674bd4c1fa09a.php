<?php

// TwigBundle:Exception:exception.js.twig
return array (
);
