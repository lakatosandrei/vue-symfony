<?php

// WebProfilerBundle:Profiler:open.css.twig
return array (
);
