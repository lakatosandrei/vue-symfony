<?php

// WebProfilerBundle:Profiler:header.html.twig
return array (
);
