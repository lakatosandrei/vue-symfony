<?php

/* AppBundle:SP:display.html.twig */
class __TwigTemplate_a8247f5f3aa7d29a76022414c7557e50302d0d4ca27c868a686e628ad8dc3c22 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("::base.html.twig", "AppBundle:SP:display.html.twig", 1);
        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'body' => array($this, 'block_body'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "::base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_1914228187b9a1b04917c0f3875fd2f64c75a8285833477b051ccce44c35abbd = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1914228187b9a1b04917c0f3875fd2f64c75a8285833477b051ccce44c35abbd->enter($__internal_1914228187b9a1b04917c0f3875fd2f64c75a8285833477b051ccce44c35abbd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:SP:display.html.twig"));

        $__internal_8ef138979ed725d97fb2288f52bed1bb14df7c6786e816ca8390a84045cdcbfe = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8ef138979ed725d97fb2288f52bed1bb14df7c6786e816ca8390a84045cdcbfe->enter($__internal_8ef138979ed725d97fb2288f52bed1bb14df7c6786e816ca8390a84045cdcbfe_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "AppBundle:SP:display.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_1914228187b9a1b04917c0f3875fd2f64c75a8285833477b051ccce44c35abbd->leave($__internal_1914228187b9a1b04917c0f3875fd2f64c75a8285833477b051ccce44c35abbd_prof);

        
        $__internal_8ef138979ed725d97fb2288f52bed1bb14df7c6786e816ca8390a84045cdcbfe->leave($__internal_8ef138979ed725d97fb2288f52bed1bb14df7c6786e816ca8390a84045cdcbfe_prof);

    }

    // line 4
    public function block_title($context, array $blocks = array())
    {
        $__internal_e71e719c51e651a583e76de16dcef026222ee1871ec30d341ab4f601c90eb72e = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_e71e719c51e651a583e76de16dcef026222ee1871ec30d341ab4f601c90eb72e->enter($__internal_e71e719c51e651a583e76de16dcef026222ee1871ec30d341ab4f601c90eb72e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_53aa1797cf2f23dbdc7d9003c0d1b63eac7896b5ba7d81a2fbefc62ce2bbd9c8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_53aa1797cf2f23dbdc7d9003c0d1b63eac7896b5ba7d81a2fbefc62ce2bbd9c8->enter($__internal_53aa1797cf2f23dbdc7d9003c0d1b63eac7896b5ba7d81a2fbefc62ce2bbd9c8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "AppBundle:SP:display";
        
        $__internal_53aa1797cf2f23dbdc7d9003c0d1b63eac7896b5ba7d81a2fbefc62ce2bbd9c8->leave($__internal_53aa1797cf2f23dbdc7d9003c0d1b63eac7896b5ba7d81a2fbefc62ce2bbd9c8_prof);

        
        $__internal_e71e719c51e651a583e76de16dcef026222ee1871ec30d341ab4f601c90eb72e->leave($__internal_e71e719c51e651a583e76de16dcef026222ee1871ec30d341ab4f601c90eb72e_prof);

    }

    // line 6
    public function block_body($context, array $blocks = array())
    {
        $__internal_1a0379fdf6d2979e570b8ecc7a5cc3249f67555e3fe6f1a05339e651981e8d28 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_1a0379fdf6d2979e570b8ecc7a5cc3249f67555e3fe6f1a05339e651981e8d28->enter($__internal_1a0379fdf6d2979e570b8ecc7a5cc3249f67555e3fe6f1a05339e651981e8d28_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_1e04dd8fc8a270eb4699b1ca91c64e5ac70bab17416def46ec4080410d23201d = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1e04dd8fc8a270eb4699b1ca91c64e5ac70bab17416def46ec4080410d23201d->enter($__internal_1e04dd8fc8a270eb4699b1ca91c64e5ac70bab17416def46ec4080410d23201d_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 7
        echo "    ";
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "8d9955a_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_8d9955a_0") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/css/app_part_1_deposit_station_1.css");
            // line 8
            echo "    <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, ($context["asset_url"] ?? $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" />
    ";
        } else {
            // asset "8d9955a"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_8d9955a") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/css/app.css");
            echo "    <link rel=\"stylesheet\" href=\"";
            echo twig_escape_filter($this->env, ($context["asset_url"] ?? $this->getContext($context, "asset_url")), "html", null, true);
            echo "\" />
    ";
        }
        unset($context["asset_url"]);
        // line 10
        echo "    <div id=\"app\"></div>
    ";
        // line 11
        if (isset($context['assetic']['debug']) && $context['assetic']['debug']) {
            // asset "9c5dbf4_0"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_9c5dbf4_0") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/js/app_part_1_ajax_1.js");
            // line 15
            echo "    <script src=\"";
            echo twig_escape_filter($this->env, ($context["asset_url"] ?? $this->getContext($context, "asset_url")), "html", null, true);
            echo "\"></script>
    ";
            // asset "9c5dbf4_1"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_9c5dbf4_1") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/js/app_part_1_vue_2.js");
            echo "    <script src=\"";
            echo twig_escape_filter($this->env, ($context["asset_url"] ?? $this->getContext($context, "asset_url")), "html", null, true);
            echo "\"></script>
    ";
            // asset "9c5dbf4_2"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_9c5dbf4_2") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/js/app_part_2_depositstation_1.js");
            echo "    <script src=\"";
            echo twig_escape_filter($this->env, ($context["asset_url"] ?? $this->getContext($context, "asset_url")), "html", null, true);
            echo "\"></script>
    ";
            // asset "9c5dbf4_3"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_9c5dbf4_3") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/js/app_main_3.js");
            echo "    <script src=\"";
            echo twig_escape_filter($this->env, ($context["asset_url"] ?? $this->getContext($context, "asset_url")), "html", null, true);
            echo "\"></script>
    ";
        } else {
            // asset "9c5dbf4"
            $context["asset_url"] = isset($context['assetic']['use_controller']) && $context['assetic']['use_controller'] ? $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_assetic_9c5dbf4") : $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("_controller/js/app.js");
            echo "    <script src=\"";
            echo twig_escape_filter($this->env, ($context["asset_url"] ?? $this->getContext($context, "asset_url")), "html", null, true);
            echo "\"></script>
    ";
        }
        unset($context["asset_url"]);
        
        $__internal_1e04dd8fc8a270eb4699b1ca91c64e5ac70bab17416def46ec4080410d23201d->leave($__internal_1e04dd8fc8a270eb4699b1ca91c64e5ac70bab17416def46ec4080410d23201d_prof);

        
        $__internal_1a0379fdf6d2979e570b8ecc7a5cc3249f67555e3fe6f1a05339e651981e8d28->leave($__internal_1a0379fdf6d2979e570b8ecc7a5cc3249f67555e3fe6f1a05339e651981e8d28_prof);

    }

    public function getTemplateName()
    {
        return "AppBundle:SP:display.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 15,  90 => 11,  87 => 10,  73 => 8,  68 => 7,  59 => 6,  41 => 4,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends \"::base.html.twig\" %}


{% block title %}AppBundle:SP:display{% endblock %}

{% block body %}
    {% stylesheets 'bundles/app/css/*' output=\"css/app.css\" %}
    <link rel=\"stylesheet\" href=\"{{ asset_url }}\" />
    {% endstylesheets %}
    <div id=\"app\"></div>
    {% javascripts
    '@AppBundle/Resources/public/js/framework/*'
    '@AppBundle/Resources/public/js/src/components/*'
    '@AppBundle/Resources/public/js/src/main.js' output=\"js/app.js\" %}
    <script src=\"{{ asset_url }}\"></script>
    {% endjavascripts %}
{% endblock %}
", "AppBundle:SP:display.html.twig", "/Users/andreilakatos/Downloads/Test Symphony/SymfonyTest/site/src/AppBundle/Resources/views/SP/display.html.twig");
    }
}
