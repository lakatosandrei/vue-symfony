<?php

/* ::base.html.twig */
class __TwigTemplate_5aee9fbe55b150d8c745c41ed65c1f21d7c3af4ae33395c2037f5058bfaf7389 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body' => array($this, 'block_body'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_971262d652584944dba33eae64441475ca233fdb4b40734ca1caac3fc567ad21 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_971262d652584944dba33eae64441475ca233fdb4b40734ca1caac3fc567ad21->enter($__internal_971262d652584944dba33eae64441475ca233fdb4b40734ca1caac3fc567ad21_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::base.html.twig"));

        $__internal_f75925c2f33b3161940dfb16063c0598126834fd17b622ec9e26624a256544a8 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f75925c2f33b3161940dfb16063c0598126834fd17b622ec9e26624a256544a8->enter($__internal_f75925c2f33b3161940dfb16063c0598126834fd17b622ec9e26624a256544a8_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "::base.html.twig"));

        // line 1
        echo "<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>";
        // line 5
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
        ";
        // line 6
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 7
        echo "        <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\" />
    </head>
    <body>
        ";
        // line 10
        $this->displayBlock('body', $context, $blocks);
        // line 11
        echo "        ";
        $this->displayBlock('javascripts', $context, $blocks);
        // line 12
        echo "    </body>
</html>
";
        
        $__internal_971262d652584944dba33eae64441475ca233fdb4b40734ca1caac3fc567ad21->leave($__internal_971262d652584944dba33eae64441475ca233fdb4b40734ca1caac3fc567ad21_prof);

        
        $__internal_f75925c2f33b3161940dfb16063c0598126834fd17b622ec9e26624a256544a8->leave($__internal_f75925c2f33b3161940dfb16063c0598126834fd17b622ec9e26624a256544a8_prof);

    }

    // line 5
    public function block_title($context, array $blocks = array())
    {
        $__internal_2077a76ceb536c202bc870521a1d16b6e68001e7fa2b5dc74bd8cce31b2f6dcb = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_2077a76ceb536c202bc870521a1d16b6e68001e7fa2b5dc74bd8cce31b2f6dcb->enter($__internal_2077a76ceb536c202bc870521a1d16b6e68001e7fa2b5dc74bd8cce31b2f6dcb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_59302a31123e4959660e788cdb9d9aab0570a7af9b6fd6133d600f6b2a7c100a = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_59302a31123e4959660e788cdb9d9aab0570a7af9b6fd6133d600f6b2a7c100a->enter($__internal_59302a31123e4959660e788cdb9d9aab0570a7af9b6fd6133d600f6b2a7c100a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Welcome!";
        
        $__internal_59302a31123e4959660e788cdb9d9aab0570a7af9b6fd6133d600f6b2a7c100a->leave($__internal_59302a31123e4959660e788cdb9d9aab0570a7af9b6fd6133d600f6b2a7c100a_prof);

        
        $__internal_2077a76ceb536c202bc870521a1d16b6e68001e7fa2b5dc74bd8cce31b2f6dcb->leave($__internal_2077a76ceb536c202bc870521a1d16b6e68001e7fa2b5dc74bd8cce31b2f6dcb_prof);

    }

    // line 6
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_bcbd47dd61efd52a201dcac8598bfa515e320beeb4637ba40edf32326d459768 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_bcbd47dd61efd52a201dcac8598bfa515e320beeb4637ba40edf32326d459768->enter($__internal_bcbd47dd61efd52a201dcac8598bfa515e320beeb4637ba40edf32326d459768_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_533c2cba82c8f224f0b2e0914be7a6893f38d76cae22c11935fc1d056d79046b = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_533c2cba82c8f224f0b2e0914be7a6893f38d76cae22c11935fc1d056d79046b->enter($__internal_533c2cba82c8f224f0b2e0914be7a6893f38d76cae22c11935fc1d056d79046b_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        
        $__internal_533c2cba82c8f224f0b2e0914be7a6893f38d76cae22c11935fc1d056d79046b->leave($__internal_533c2cba82c8f224f0b2e0914be7a6893f38d76cae22c11935fc1d056d79046b_prof);

        
        $__internal_bcbd47dd61efd52a201dcac8598bfa515e320beeb4637ba40edf32326d459768->leave($__internal_bcbd47dd61efd52a201dcac8598bfa515e320beeb4637ba40edf32326d459768_prof);

    }

    // line 10
    public function block_body($context, array $blocks = array())
    {
        $__internal_a4a0c694bc44136b85391aadd4eb4b240900f63cb0d7c889a2faa5cf0f1caff9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_a4a0c694bc44136b85391aadd4eb4b240900f63cb0d7c889a2faa5cf0f1caff9->enter($__internal_a4a0c694bc44136b85391aadd4eb4b240900f63cb0d7c889a2faa5cf0f1caff9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_590a13b0c418f7cc9b2cdd53f2265f652fa18bc334c258424265ac2f011403d3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_590a13b0c418f7cc9b2cdd53f2265f652fa18bc334c258424265ac2f011403d3->enter($__internal_590a13b0c418f7cc9b2cdd53f2265f652fa18bc334c258424265ac2f011403d3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        
        $__internal_590a13b0c418f7cc9b2cdd53f2265f652fa18bc334c258424265ac2f011403d3->leave($__internal_590a13b0c418f7cc9b2cdd53f2265f652fa18bc334c258424265ac2f011403d3_prof);

        
        $__internal_a4a0c694bc44136b85391aadd4eb4b240900f63cb0d7c889a2faa5cf0f1caff9->leave($__internal_a4a0c694bc44136b85391aadd4eb4b240900f63cb0d7c889a2faa5cf0f1caff9_prof);

    }

    // line 11
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_b133014bd4c30497dfb764c3e8e992ea4882f277c3a63e5bb2ae6d2e84991914 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_b133014bd4c30497dfb764c3e8e992ea4882f277c3a63e5bb2ae6d2e84991914->enter($__internal_b133014bd4c30497dfb764c3e8e992ea4882f277c3a63e5bb2ae6d2e84991914_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_8e2187e3aed31e2a28cfcfc9e136f61b74d292a4f472a6acfcc3843c2c166a2f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_8e2187e3aed31e2a28cfcfc9e136f61b74d292a4f472a6acfcc3843c2c166a2f->enter($__internal_8e2187e3aed31e2a28cfcfc9e136f61b74d292a4f472a6acfcc3843c2c166a2f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        
        $__internal_8e2187e3aed31e2a28cfcfc9e136f61b74d292a4f472a6acfcc3843c2c166a2f->leave($__internal_8e2187e3aed31e2a28cfcfc9e136f61b74d292a4f472a6acfcc3843c2c166a2f_prof);

        
        $__internal_b133014bd4c30497dfb764c3e8e992ea4882f277c3a63e5bb2ae6d2e84991914->leave($__internal_b133014bd4c30497dfb764c3e8e992ea4882f277c3a63e5bb2ae6d2e84991914_prof);

    }

    public function getTemplateName()
    {
        return "::base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  117 => 11,  100 => 10,  83 => 6,  65 => 5,  53 => 12,  50 => 11,  48 => 10,  41 => 7,  39 => 6,  35 => 5,  29 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("<!DOCTYPE html>
<html>
    <head>
        <meta charset=\"UTF-8\" />
        <title>{% block title %}Welcome!{% endblock %}</title>
        {% block stylesheets %}{% endblock %}
        <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\" />
    </head>
    <body>
        {% block body %}{% endblock %}
        {% block javascripts %}{% endblock %}
    </body>
</html>
", "::base.html.twig", "/Users/andreilakatos/Downloads/Test Symphony/SymfonyTest/site/app/Resources/views/base.html.twig");
    }
}
