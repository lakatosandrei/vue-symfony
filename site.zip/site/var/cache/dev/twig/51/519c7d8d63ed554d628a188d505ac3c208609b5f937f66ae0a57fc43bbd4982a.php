<?php

/* @Twig/Exception/exception.js.twig */
class __TwigTemplate_9d7930e548ca01a39762fa993373a55179b5ce72b9d5b1523fcf5b1f885bfb2b extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_81867273fed09709413ad547af26cf0917f8739b268ea57acfa4e54a8d28ce00 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_81867273fed09709413ad547af26cf0917f8739b268ea57acfa4e54a8d28ce00->enter($__internal_81867273fed09709413ad547af26cf0917f8739b268ea57acfa4e54a8d28ce00_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.js.twig"));

        $__internal_7d9d697cf7010d4a5d6b60649065a25a2a123a3234b9c60da6e2da59e23f668f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7d9d697cf7010d4a5d6b60649065a25a2a123a3234b9c60da6e2da59e23f668f->enter($__internal_7d9d697cf7010d4a5d6b60649065a25a2a123a3234b9c60da6e2da59e23f668f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@Twig/Exception/exception.js.twig"));

        // line 1
        echo "/*
";
        // line 2
        $this->loadTemplate("@Twig/Exception/exception.txt.twig", "@Twig/Exception/exception.js.twig", 2)->display(array_merge($context, array("exception" => ($context["exception"] ?? $this->getContext($context, "exception")))));
        // line 3
        echo "*/
";
        
        $__internal_81867273fed09709413ad547af26cf0917f8739b268ea57acfa4e54a8d28ce00->leave($__internal_81867273fed09709413ad547af26cf0917f8739b268ea57acfa4e54a8d28ce00_prof);

        
        $__internal_7d9d697cf7010d4a5d6b60649065a25a2a123a3234b9c60da6e2da59e23f668f->leave($__internal_7d9d697cf7010d4a5d6b60649065a25a2a123a3234b9c60da6e2da59e23f668f_prof);

    }

    public function getTemplateName()
    {
        return "@Twig/Exception/exception.js.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  30 => 3,  28 => 2,  25 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("/*
{% include '@Twig/Exception/exception.txt.twig' with { 'exception': exception } %}
*/
", "@Twig/Exception/exception.js.twig", "/Users/andreilakatos/Downloads/Test Symphony/SymfonyTest/site/vendor/symfony/symfony/src/Symfony/Bundle/TwigBundle/Resources/views/Exception/exception.js.twig");
    }
}
