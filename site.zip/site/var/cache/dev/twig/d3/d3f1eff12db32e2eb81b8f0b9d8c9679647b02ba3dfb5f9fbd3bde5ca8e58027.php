<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_91a0bc076dfbb68daa10e559b254160b0394769e5c3cb34ea2eac24a6902a42e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_373971b1314addcdd08f32af54e7012a4bd9b8197fd76ad0a3a197a8ec73f9a4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_373971b1314addcdd08f32af54e7012a4bd9b8197fd76ad0a3a197a8ec73f9a4->enter($__internal_373971b1314addcdd08f32af54e7012a4bd9b8197fd76ad0a3a197a8ec73f9a4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_66e68be2804765965ed1569b2c3e6a93d247e9c6d655bfcc5f23bc7bad195cb2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_66e68be2804765965ed1569b2c3e6a93d247e9c6d655bfcc5f23bc7bad195cb2->enter($__internal_66e68be2804765965ed1569b2c3e6a93d247e9c6d655bfcc5f23bc7bad195cb2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_373971b1314addcdd08f32af54e7012a4bd9b8197fd76ad0a3a197a8ec73f9a4->leave($__internal_373971b1314addcdd08f32af54e7012a4bd9b8197fd76ad0a3a197a8ec73f9a4_prof);

        
        $__internal_66e68be2804765965ed1569b2c3e6a93d247e9c6d655bfcc5f23bc7bad195cb2->leave($__internal_66e68be2804765965ed1569b2c3e6a93d247e9c6d655bfcc5f23bc7bad195cb2_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_19267f3475301e32f6f6b7edb7af4fa8b37852c4a45615ac16b6a61b6068e8d5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_19267f3475301e32f6f6b7edb7af4fa8b37852c4a45615ac16b6a61b6068e8d5->enter($__internal_19267f3475301e32f6f6b7edb7af4fa8b37852c4a45615ac16b6a61b6068e8d5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_88426e4021d234d79d06d907b5319830d581ae531c85b860c2f0bd8230ff00ec = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_88426e4021d234d79d06d907b5319830d581ae531c85b860c2f0bd8230ff00ec->enter($__internal_88426e4021d234d79d06d907b5319830d581ae531c85b860c2f0bd8230ff00ec_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_88426e4021d234d79d06d907b5319830d581ae531c85b860c2f0bd8230ff00ec->leave($__internal_88426e4021d234d79d06d907b5319830d581ae531c85b860c2f0bd8230ff00ec_prof);

        
        $__internal_19267f3475301e32f6f6b7edb7af4fa8b37852c4a45615ac16b6a61b6068e8d5->leave($__internal_19267f3475301e32f6f6b7edb7af4fa8b37852c4a45615ac16b6a61b6068e8d5_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_dcb770eebe557ffafef57084c44e24c49228a75d3da60f9d1d83e0ec77879407 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_dcb770eebe557ffafef57084c44e24c49228a75d3da60f9d1d83e0ec77879407->enter($__internal_dcb770eebe557ffafef57084c44e24c49228a75d3da60f9d1d83e0ec77879407_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_887d5950f6d968d0d03d88dfa1b8018d40dfc6bf1eab8a57fa7ef798ccec74bb = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_887d5950f6d968d0d03d88dfa1b8018d40dfc6bf1eab8a57fa7ef798ccec74bb->enter($__internal_887d5950f6d968d0d03d88dfa1b8018d40dfc6bf1eab8a57fa7ef798ccec74bb_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_887d5950f6d968d0d03d88dfa1b8018d40dfc6bf1eab8a57fa7ef798ccec74bb->leave($__internal_887d5950f6d968d0d03d88dfa1b8018d40dfc6bf1eab8a57fa7ef798ccec74bb_prof);

        
        $__internal_dcb770eebe557ffafef57084c44e24c49228a75d3da60f9d1d83e0ec77879407->leave($__internal_dcb770eebe557ffafef57084c44e24c49228a75d3da60f9d1d83e0ec77879407_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_c172c4302f97303d5ff1f237945789d3d094d9ecdb37055fdbfd9ebd4be8b98c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_c172c4302f97303d5ff1f237945789d3d094d9ecdb37055fdbfd9ebd4be8b98c->enter($__internal_c172c4302f97303d5ff1f237945789d3d094d9ecdb37055fdbfd9ebd4be8b98c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_1cc2fc48f3dd360dd335755ca24460bad3a43c97635c04c852acfabbadf8b6f6 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_1cc2fc48f3dd360dd335755ca24460bad3a43c97635c04c852acfabbadf8b6f6->enter($__internal_1cc2fc48f3dd360dd335755ca24460bad3a43c97635c04c852acfabbadf8b6f6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_1cc2fc48f3dd360dd335755ca24460bad3a43c97635c04c852acfabbadf8b6f6->leave($__internal_1cc2fc48f3dd360dd335755ca24460bad3a43c97635c04c852acfabbadf8b6f6_prof);

        
        $__internal_c172c4302f97303d5ff1f237945789d3d094d9ecdb37055fdbfd9ebd4be8b98c->leave($__internal_c172c4302f97303d5ff1f237945789d3d094d9ecdb37055fdbfd9ebd4be8b98c_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "/Users/andreilakatos/Downloads/Test Symphony/SymfonyTest/site/vendor/symfony/symfony/src/Symfony/Bundle/WebProfilerBundle/Resources/views/Collector/router.html.twig");
    }
}
